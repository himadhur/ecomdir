-- Drop existing functions
DROP FUNCTION IF EXISTS get_distinct_categories();
DROP FUNCTION IF EXISTS get_distinct_sub_categories();
DROP FUNCTION IF EXISTS get_distinct_locations();

-- Create improved functions with table aliases to avoid ambiguity
CREATE OR REPLACE FUNCTION get_distinct_categories()
RETURNS TABLE (category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT l.product_category
  FROM leads l
  WHERE l.product_category IS NOT NULL
  ORDER BY l.product_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_sub_categories()
RETURNS TABLE (sub_category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT l.sub_category
  FROM leads l
  WHERE l.sub_category IS NOT NULL
  ORDER BY l.sub_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_locations()
RETURNS TABLE (location text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT l.location
  FROM leads l
  WHERE l.location IS NOT NULL
  ORDER BY l.location;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ensure indexes exist
CREATE INDEX IF NOT EXISTS idx_leads_product_category ON leads(product_category);
CREATE INDEX IF NOT EXISTS idx_leads_sub_category ON leads(sub_category);
CREATE INDEX IF NOT EXISTS idx_leads_location ON leads(location);