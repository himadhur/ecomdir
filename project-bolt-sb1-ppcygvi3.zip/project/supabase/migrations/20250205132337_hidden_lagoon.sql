/*
  # Add profile fields

  1. Changes
    - Add new columns to profiles table:
      - full_name (text)
      - company_name (text)
      - phone (text)

  2. Notes
    - All fields are nullable since they're optional profile information
    - Existing RLS policies will automatically apply to new columns
*/

ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS full_name text,
ADD COLUMN IF NOT EXISTS company_name text,
ADD COLUMN IF NOT EXISTS phone text;