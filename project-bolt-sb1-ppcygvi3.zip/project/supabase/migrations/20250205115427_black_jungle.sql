/*
  # Grant admin role to specific user

  1. Changes
    - Grant admin role to authenticated users
    - Create policy for admin user by email
  
  2. Security
    - Only allows specific email to perform admin actions
    - Maintains existing RLS policies
*/

-- Grant admin role to authenticated users
GRANT admin TO authenticated;

-- Create a policy that checks the user's email
CREATE POLICY "Only specific admin can manage leads"
  ON leads
  FOR ALL
  TO admin
  USING (auth.jwt() ->> 'email' = 'tarrkash@gmail.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'tarrkash@gmail.com');