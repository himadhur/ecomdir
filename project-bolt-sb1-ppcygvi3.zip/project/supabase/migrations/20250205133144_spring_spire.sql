/*
  # Fix downloads table schema

  1. Changes
    - Add indexes for better performance
    - Add columns for file metadata
    - Update RLS policies

  2. Security
    - Maintain existing RLS
    - Add policies for new operations
*/

-- Add new columns for better tracking
ALTER TABLE downloads
ADD COLUMN IF NOT EXISTS status text DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed')),
ADD COLUMN IF NOT EXISTS download_count integer DEFAULT 0;

-- Create function to increment download count
CREATE OR REPLACE FUNCTION increment_download_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE downloads
  SET download_count = download_count + 1
  WHERE id = NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for download count
CREATE OR REPLACE TRIGGER on_download_increment
  AFTER UPDATE OF status ON downloads
  FOR EACH ROW
  WHEN (NEW.status = 'completed')
  EXECUTE FUNCTION increment_download_count();

-- Create index for faster status filtering
CREATE INDEX IF NOT EXISTS downloads_status_idx ON downloads (status);

-- Update RLS policies
DROP POLICY IF EXISTS "Users can read own downloads" ON downloads;
DROP POLICY IF EXISTS "Users can insert own downloads" ON downloads;

CREATE POLICY "Users can read own downloads"
  ON downloads
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own downloads"
  ON downloads
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own downloads"
  ON downloads
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);