/*
  # Update admin policy for leads management

  1. Changes
    - Drop existing policy
    - Create new policy with updated admin email
  
  2. Security
    - Maintains RLS
    - Updates policy to allow specific admin access
*/

-- Drop the existing policy
DROP POLICY IF EXISTS "Only specific admin can manage leads" ON leads;

-- Create new policy with updated admin email
CREATE POLICY "Only specific admin can manage leads"
  ON leads
  FOR ALL
  TO admin
  USING (
    auth.jwt() ->> 'email' IN ('tarrkash@gmail.com')
  )
  WITH CHECK (
    auth.jwt() ->> 'email' IN ('tarrkash@gmail.com')
  );