/*
  # Add stored procedures for distinct values

  1. New Functions
    - get_distinct_categories: Returns distinct product categories
    - get_distinct_sales_buckets: Returns distinct annual sales buckets
    - get_distinct_price_buckets: Returns distinct product price buckets
*/

CREATE OR REPLACE FUNCTION get_distinct_categories()
RETURNS TABLE (category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT product_category
  FROM leads
  ORDER BY product_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_sales_buckets()
RETURNS TABLE (bucket text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT annual_sales_bucket
  FROM leads
  WHERE annual_sales_bucket IS NOT NULL
  ORDER BY annual_sales_bucket;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_price_buckets()
RETURNS TABLE (bucket text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT product_price_bucket
  FROM leads
  WHERE product_price_bucket IS NOT NULL
  ORDER BY product_price_bucket;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;