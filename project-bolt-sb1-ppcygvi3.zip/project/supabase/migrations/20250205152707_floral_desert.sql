-- Insert sample data
INSERT INTO leads (
  brand_name,
  monthly_sales,
  product_category,
  sub_category,
  location,
  avg_price,
  avg_sales,
  website,
  email,
  phone,
  created_at,
  annual_sales,
  annual_sales_bucket,
  product_price_bucket,
  rating,
  reviews,
  storefront
)
VALUES
  ('TechGear Pro', 85000, 'Electronics', 'Accessories', 'US', 129.99, 75000, 'https://example.com', 'contact@techgear.com', '+1234567890', now(), 1020000, 'Over_1M', '100_to_500', 4.7, 1250, true),
  ('EcoHome', 62000, 'Home & Kitchen', 'Sustainable Products', 'CA', 45.99, 58000, 'https://ecohome.com', 'info@ecohome.com', '+1987654321', now(), 744000, '500K_to_1M', '25_to_100', 4.5, 890, true),
  ('FitLife', 43000, 'Sports & Outdoors', 'Fitness Equipment', 'UK', 89.99, 40000, 'https://fitlife.co.uk', 'sales@fitlife.co.uk', '+4412345678', now(), 516000, '500K_to_1M', '50_to_100', 4.8, 2100, true);