/*
  # Leads Database Schema

  1. New Tables
    - leads
      - id (uuid, primary key)
      - brand_name (text)
      - monthly_sales (numeric)
      - product_category (text)
      - sub_category (text)
      - location (text)
      - avg_price (numeric)
      - avg_sales (numeric)
      - website (text)
      - email (text)
      - phone (text)
      - created_at (timestamp)
      - updated_at (timestamp)

  2. Security
    - Enable RLS on leads table
    - Add policies for authenticated users to view leads
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_name text NOT NULL,
  monthly_sales numeric NOT NULL,
  product_category text NOT NULL,
  sub_category text,
  location text,
  avg_price numeric,
  avg_sales numeric,
  website text,
  email text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated users can view leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes for better search performance
CREATE INDEX IF NOT EXISTS leads_brand_name_idx ON leads (brand_name);
CREATE INDEX IF NOT EXISTS leads_product_category_idx ON leads (product_category);
CREATE INDEX IF NOT EXISTS leads_monthly_sales_idx ON leads (monthly_sales);
CREATE INDEX IF NOT EXISTS leads_location_idx ON leads (location);