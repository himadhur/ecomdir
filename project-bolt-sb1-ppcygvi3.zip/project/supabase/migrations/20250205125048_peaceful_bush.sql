/*
  # Add downloads tracking

  1. New Tables
    - `downloads`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `created_at` (timestamp)
      - `file_name` (text)
      - `lead_count` (integer)
      - `total_size` (bigint)
      - `leads` (jsonb)

  2. Security
    - Enable RLS on `downloads` table
    - Add policy for authenticated users to read their own downloads
*/

CREATE TABLE IF NOT EXISTS downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  file_name text NOT NULL,
  lead_count integer NOT NULL,
  total_size bigint NOT NULL,
  leads jsonb NOT NULL
);

-- Enable RLS
ALTER TABLE downloads ENABLE ROW LEVEL SECURITY;

-- Create policy for users to read their own downloads
CREATE POLICY "Users can read own downloads"
  ON downloads
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policy for users to insert their own downloads
CREATE POLICY "Users can insert own downloads"
  ON downloads
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS downloads_user_id_idx ON downloads (user_id);
CREATE INDEX IF NOT EXISTS downloads_created_at_idx ON downloads (created_at DESC);