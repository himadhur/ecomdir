/*
  # Admin Leads Policy

  1. Security Changes
    - Add policy for administrators to insert leads
    - Add policy for administrators to update leads
*/

-- Create an admin role
CREATE ROLE admin;

-- Create policy for admin leads management
CREATE POLICY "Administrators can insert leads"
  ON leads
  FOR INSERT
  TO admin
  WITH CHECK (true);

CREATE POLICY "Administrators can update leads"
  ON leads
  FOR UPDATE
  TO admin
  USING (true)
  WITH CHECK (true);