-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_leads_product_category ON leads(product_category);
CREATE INDEX IF NOT EXISTS idx_leads_sub_category ON leads(sub_category);
CREATE INDEX IF NOT EXISTS idx_leads_location ON leads(location);
CREATE INDEX IF NOT EXISTS idx_leads_avg_price ON leads(avg_price);
CREATE INDEX IF NOT EXISTS idx_leads_annual_sales ON leads(annual_sales);
CREATE INDEX IF NOT EXISTS idx_leads_reviews ON leads(reviews);
CREATE INDEX IF NOT EXISTS idx_leads_storefront ON leads(storefront);

-- Update RPC functions to handle NULL values better
CREATE OR REPLACE FUNCTION get_distinct_categories()
RETURNS TABLE (category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT product_category
  FROM leads
  WHERE product_category IS NOT NULL
  ORDER BY product_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_sub_categories()
RETURNS TABLE (sub_category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT sub_category
  FROM leads
  WHERE sub_category IS NOT NULL
  ORDER BY sub_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_locations()
RETURNS TABLE (location text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT location
  FROM leads
  WHERE location IS NOT NULL
  ORDER BY location;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;