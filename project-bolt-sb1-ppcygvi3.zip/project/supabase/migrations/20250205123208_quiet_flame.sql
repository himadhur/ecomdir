/*
  # Add more leads to the database

  1. Changes
    - Adds 10 new leads to the database with various categories and sales ranges
*/

INSERT INTO leads (
  brand_name,
  monthly_sales,
  product_category,
  sub_category,
  location,
  avg_price,
  avg_sales,
  website,
  email,
  phone,
  created_at,
  annual_sales,
  annual_sales_bucket,
  product_price_bucket,
  rating,
  reviews,
  storefront
)
VALUES
  ('WorkspaceEssentials', 92000, 'Office Products', 'Ergonomic Furniture', 'US', 399.99, 88000, NULL, NULL, NULL, now(), 1104000, 'Over_1M', 'Over_500', 4.8, 1850, true),
  ('PetGourmet', 31000, 'Pet Supplies', 'Premium Pet Food', 'CA', 79.99, 29000, NULL, NULL, NULL, now(), 372000, '250K_to_500K', '50_to_100', 4.6, 920, true),
  ('GamingPro', 78000, 'Electronics', 'Gaming Accessories', 'UK', 159.99, 75000, NULL, NULL, NULL, now(), 936000, '500K_to_1M', '100_to_500', 4.9, 3100, true),
  ('YogaLife', 45000, 'Sports & Outdoors', 'Yoga Equipment', 'AU', 49.99, 42000, NULL, NULL, NULL, now(), 540000, '500K_to_1M', '25_to_50', 4.7, 1560, false),
  ('SmartKitchen', 67000, 'Home & Kitchen', 'Smart Appliances', 'DE', 299.99, 64000, NULL, NULL, NULL, now(), 804000, '500K_to_1M', 'Over_500', 4.5, 890, true),
  ('BeautyLuxe', 83000, 'Beauty & Personal Care', 'Luxury Skincare', 'FR', 129.99, 80000, NULL, NULL, NULL, now(), 996000, '500K_to_1M', '100_to_500', 4.8, 2700, true),
  ('KidsEducation', 41000, 'Toys & Games', 'STEM Toys', 'US', 69.99, 38000, NULL, NULL, NULL, now(), 492000, '250K_to_500K', '50_to_100', 4.6, 1100, true),
  ('HomeDecor', 58000, 'Home & Kitchen', 'Modern Decor', 'CA', 89.99, 55000, NULL, NULL, NULL, now(), 696000, '500K_to_1M', '50_to_100', 4.7, 1450, true),
  ('OutdoorGear', 72000, 'Sports & Outdoors', 'Hiking Equipment', 'NZ', 199.99, 69000, NULL, NULL, NULL, now(), 864000, '500K_to_1M', '100_to_500', 4.8, 1920, true),
  ('TechInnovate', 95000, 'Electronics', 'Smart Home Devices', 'US', 249.99, 91000, NULL, NULL, NULL, now(), 1140000, 'Over_1M', '100_to_500', 4.9, 3400, true);