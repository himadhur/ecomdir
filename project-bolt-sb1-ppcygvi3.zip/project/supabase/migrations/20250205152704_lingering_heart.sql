-- Create function to get distinct categories with proper typing
CREATE OR REPLACE FUNCTION get_distinct_categories()
RETURNS TABLE (category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT product_category
  FROM leads
  WHERE product_category IS NOT NULL
  ORDER BY product_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get distinct sub-categories
CREATE OR REPLACE FUNCTION get_distinct_sub_categories()
RETURNS TABLE (sub_category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT sub_category
  FROM leads
  WHERE sub_category IS NOT NULL
  ORDER BY sub_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get distinct locations
CREATE OR REPLACE FUNCTION get_distinct_locations()
RETURNS TABLE (location text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT location
  FROM leads
  WHERE location IS NOT NULL
  ORDER BY location;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;