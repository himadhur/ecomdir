/*
  # Add credit transactions tracking

  1. New Tables
    - `credit_transactions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `amount` (integer)
      - `type` (text)
      - `description` (text)
      - `created_at` (timestamp)
      - `payment_id` (text)
      - `payment_status` (text)

  2. Security
    - Enable RLS on `credit_transactions` table
    - Add policy for authenticated users to read their own transactions
    - Add policy for authenticated users to insert transactions
*/

CREATE TABLE IF NOT EXISTS credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  amount integer NOT NULL,
  type text NOT NULL CHECK (type IN ('purchase', 'usage')),
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  payment_id text,
  payment_status text CHECK (payment_status IN ('pending', 'completed', 'failed'))
);

-- Enable RLS
ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;

-- Create policy for users to read their own transactions
CREATE POLICY "Users can read own transactions"
  ON credit_transactions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policy for users to insert their own transactions
CREATE POLICY "Users can insert own transactions"
  ON credit_transactions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS credit_transactions_user_id_idx ON credit_transactions (user_id);
CREATE INDEX IF NOT EXISTS credit_transactions_created_at_idx ON credit_transactions (created_at DESC);