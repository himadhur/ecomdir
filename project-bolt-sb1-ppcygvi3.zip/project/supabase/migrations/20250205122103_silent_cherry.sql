/*
  # Add more leads to the database

  1. Changes
    - Adds more lead records to the leads table
    - Maintains existing data structure
    - Includes calculated monthly sales values
*/

INSERT INTO leads (
  brand_name,
  monthly_sales,
  product_category,
  sub_category,
  location,
  avg_price,
  avg_sales,
  website,
  email,
  phone,
  created_at,
  annual_sales,
  annual_sales_bucket,
  product_price_bucket,
  rating,
  reviews,
  storefront
)
VALUES
  ('TechGear Pro', 85000, 'Electronics', 'Accessories', 'US', 129.99, 75000, 'https://example.com', NULL, NULL, now(), 1020000, 'Over_1M', '100_to_500', 4.7, 1250, true),
  ('EcoHome', 62000, 'Home & Kitchen', 'Sustainable Products', 'CA', 45.99, 58000, NULL, NULL, NULL, now(), 744000, '500K_to_1M', '25_to_100', 4.5, 890, true),
  ('FitLife', 43000, 'Sports & Outdoors', 'Fitness Equipment', 'UK', 89.99, 40000, NULL, NULL, NULL, now(), 516000, '500K_to_1M', '50_to_100', 4.8, 2100, true),
  ('GourmetBasics', 38000, 'Grocery & Gourmet Food', 'Organic', 'FR', 34.99, 35000, NULL, NULL, NULL, now(), 456000, '250K_to_500K', '25_to_50', 4.6, 780, false),
  ('PetPals', 29000, 'Pet Supplies', 'Dog Accessories', 'DE', 25.99, 27000, NULL, NULL, NULL, now(), 348000, '250K_to_500K', '25_to_50', 4.4, 1560, true),
  ('BeautyGlow', 56000, 'Beauty & Personal Care', 'Skincare', 'US', 79.99, 52000, NULL, NULL, NULL, now(), 672000, '500K_to_1M', '50_to_100', 4.9, 3400, true),
  ('KidsJoy', 33000, 'Toys & Games', 'Educational Toys', 'UK', 39.99, 31000, NULL, NULL, NULL, now(), 396000, '250K_to_500K', '25_to_50', 4.7, 920, false),
  ('ArtisanCraft', 27000, 'Arts, Crafts & Sewing', 'DIY Kits', 'IT', 59.99, 25000, NULL, NULL, NULL, now(), 324000, '250K_to_500K', '50_to_100', 4.5, 670, true),
  ('GardenPro', 48000, 'Patio, Lawn & Garden', 'Garden Tools', 'ES', 149.99, 45000, NULL, NULL, NULL, now(), 576000, '500K_to_1M', '100_to_500', 4.6, 890, true),
  ('SmartHome', 71000, 'Tools & Home Improvement', 'Smart Devices', 'US', 199.99, 68000, NULL, NULL, NULL, now(), 852000, '500K_to_1M', '100_to_500', 4.8, 2300, true),
  ('HealthEssentials', 52000, 'Health & Household', 'Supplements', 'CA', 44.99, 49000, NULL, NULL, NULL, now(), 624000, '500K_to_1M', '25_to_50', 4.4, 1100, true),
  ('BabyBliss', 39000, 'Baby Products', 'Baby Care', 'AU', 69.99, 36000, NULL, NULL, NULL, now(), 468000, '250K_to_500K', '50_to_100', 4.7, 1450, false),
  ('FashionFwd', 63000, 'Clothing, Shoes & Jewelry', 'Women''s Fashion', 'FR', 89.99, 60000, NULL, NULL, NULL, now(), 756000, '500K_to_1M', '50_to_100', 4.6, 2800, true),
  ('OutdoorLife', 44000, 'Sports & Outdoors', 'Camping Gear', 'DE', 129.99, 41000, NULL, NULL, NULL, now(), 528000, '500K_to_1M', '100_to_500', 4.5, 950, true),
  ('KitchenPro', 58000, 'Home & Kitchen', 'Appliances', 'US', 299.99, 55000, NULL, NULL, NULL, now(), 696000, '500K_to_1M', 'Over_500', 4.8, 1670, true);