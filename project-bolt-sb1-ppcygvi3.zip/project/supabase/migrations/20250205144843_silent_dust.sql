/*
  # Fix RLS policies for archived leads

  1. Changes
    - Drop existing policies
    - Create new policy for non-archived leads with proper coalesce handling
    - Create new policy for admin access with proper email check
    - Add explicit policy for archiving leads

  2. Security
    - Ensure normal users can only see non-archived leads
    - Admins can see and manage all leads
    - Only admins can archive leads
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can view non-archived leads" ON leads;
DROP POLICY IF EXISTS "Administrators can view all leads" ON leads;
DROP POLICY IF EXISTS "Administrators can archive leads" ON leads;

-- Create new policy for normal users to view only non-archived leads
CREATE POLICY "Users can view non-archived leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (
    CASE 
      WHEN auth.jwt() ->> 'email' = 'tarrkash@gmail.com' THEN true
      ELSE coalesce(archived, false) = false
    END
  );

-- Create policy for archiving leads (admin only)
CREATE POLICY "Administrators can archive leads"
  ON leads
  FOR UPDATE
  TO authenticated
  USING (
    auth.jwt() ->> 'email' = 'tarrkash@gmail.com'
  )
  WITH CHECK (
    auth.jwt() ->> 'email' = 'tarrkash@gmail.com'
  );