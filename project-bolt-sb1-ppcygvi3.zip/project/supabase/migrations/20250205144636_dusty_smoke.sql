/*
  # Archive all existing leads

  1. Changes
    - Archives all existing leads
    - Sets archived_at to current timestamp
    - Sets archived_by to the system user

  2. Security
    - Maintains existing RLS policies
    - Only affects non-archived leads
*/

-- Create a function to get the system user ID
CREATE OR REPLACE FUNCTION get_system_user_id()
RETURNS uuid AS $$
BEGIN
  -- Get the first admin user's ID (assuming it's the system user)
  RETURN (
    SELECT id 
    FROM auth.users 
    WHERE email = 'tarrkash@gmail.com' 
    LIMIT 1
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Archive all existing leads
DO $$ 
DECLARE
  system_user_id uuid;
BEGIN
  -- Get the system user ID
  system_user_id := get_system_user_id();
  
  -- Update all non-archived leads
  UPDATE leads 
  SET 
    archived = true,
    archived_at = CURRENT_TIMESTAMP,
    archived_by = system_user_id
  WHERE 
    archived = false OR archived IS NULL;
END $$;