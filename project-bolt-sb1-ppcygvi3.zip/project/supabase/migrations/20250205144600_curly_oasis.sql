/*
  # Add archiving functionality to leads table

  1. Changes
    - Add archiving columns (archived, archived_at, archived_by)
    - Add index for archived status
    - Update RLS policies for archived leads
    - Create function and trigger for archiving validation

  2. Security
    - Only admins can archive leads
    - Regular users can only see non-archived leads
    - Admins can see all leads
*/

-- Add archiving columns
ALTER TABLE leads
ADD COLUMN IF NOT EXISTS archived boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS archived_at timestamptz,
ADD COLUMN IF NOT EXISTS archived_by uuid REFERENCES auth.users(id);

-- Create index for better performance when filtering archived status
CREATE INDEX IF NOT EXISTS leads_archived_idx ON leads (archived);

-- Update the existing RLS policy for viewing leads to exclude archived ones
DROP POLICY IF EXISTS "Authenticated users can view leads" ON leads;

CREATE POLICY "Authenticated users can view non-archived leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (NOT coalesce(archived, false));

-- Create policy for admins to view all leads including archived ones
CREATE POLICY "Administrators can view all leads"
  ON leads
  FOR SELECT
  TO admin
  USING (true);

-- Create function to validate archive updates
CREATE OR REPLACE FUNCTION validate_lead_archive()
RETURNS TRIGGER AS $$
BEGIN
  -- Only allow changes to archive-related columns
  IF (
    NEW.brand_name != OLD.brand_name OR
    NEW.monthly_sales != OLD.monthly_sales OR
    NEW.product_category != OLD.product_category OR
    NEW.sub_category IS DISTINCT FROM OLD.sub_category OR
    NEW.location IS DISTINCT FROM OLD.location OR
    NEW.avg_price IS DISTINCT FROM OLD.avg_price OR
    NEW.avg_sales IS DISTINCT FROM OLD.avg_sales OR
    NEW.website IS DISTINCT FROM OLD.website OR
    NEW.email IS DISTINCT FROM OLD.email OR
    NEW.phone IS DISTINCT FROM OLD.phone OR
    NEW.annual_sales IS DISTINCT FROM OLD.annual_sales OR
    NEW.annual_sales_bucket IS DISTINCT FROM OLD.annual_sales_bucket OR
    NEW.product_price_bucket IS DISTINCT FROM OLD.product_price_bucket OR
    NEW.avg_sellers IS DISTINCT FROM OLD.avg_sellers OR
    NEW.top_seller_name IS DISTINCT FROM OLD.top_seller_name OR
    NEW.top_seller_country IS DISTINCT FROM OLD.top_seller_country OR
    NEW.reviews IS DISTINCT FROM OLD.reviews OR
    NEW.rating IS DISTINCT FROM OLD.rating OR
    NEW.total_products IS DISTINCT FROM OLD.total_products OR
    NEW.storefront IS DISTINCT FROM OLD.storefront
  ) THEN
    RAISE EXCEPTION 'Only archive status can be modified';
  END IF;

  -- Ensure proper archiving
  IF NEW.archived = true AND (
    NEW.archived_at IS NULL OR
    NEW.archived_by IS NULL
  ) THEN
    RAISE EXCEPTION 'Archived leads must have archived_at and archived_by set';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for archive validation
CREATE TRIGGER validate_lead_archive_trigger
  BEFORE UPDATE ON leads
  FOR EACH ROW
  WHEN (NEW.archived = true AND OLD.archived = false)
  EXECUTE FUNCTION validate_lead_archive();

-- Create policy for archiving leads (admin only)
CREATE POLICY "Administrators can archive leads"
  ON leads
  FOR UPDATE
  TO admin
  USING (auth.jwt() ->> 'email' IN ('tarrkash@gmail.com'))
  WITH CHECK (auth.jwt() ->> 'email' IN ('tarrkash@gmail.com'));