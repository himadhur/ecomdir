-- Drop existing functions if they exist
DROP FUNCTION IF EXISTS get_distinct_categories();
DROP FUNCTION IF EXISTS get_distinct_sub_categories();
DROP FUNCTION IF EXISTS get_distinct_locations();

-- Create improved functions with better error handling
CREATE OR REPLACE FUNCTION get_distinct_categories()
RETURNS TABLE (category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT product_category
  FROM leads
  WHERE product_category IS NOT NULL
  ORDER BY product_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_sub_categories()
RETURNS TABLE (sub_category text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT sub_category
  FROM leads
  WHERE sub_category IS NOT NULL
  ORDER BY sub_category;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_distinct_locations()
RETURNS TABLE (location text) AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT location
  FROM leads
  WHERE location IS NOT NULL
  ORDER BY location;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_leads_product_category ON leads(product_category);
CREATE INDEX IF NOT EXISTS idx_leads_sub_category ON leads(sub_category);
CREATE INDEX IF NOT EXISTS idx_leads_location ON leads(location);

-- Ensure RLS policies are properly set
DROP POLICY IF EXISTS "Enable read access for all users" ON leads;
CREATE POLICY "Enable read access for all users"
  ON leads
  FOR SELECT
  TO authenticated
  USING (true);