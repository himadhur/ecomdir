/*
  # Delete all leads

  This migration safely removes all leads from the system while maintaining table structure and policies.

  1. Changes:
    - Removes all existing leads from the leads table
    - Maintains table structure and policies
    - Safe operation that can be rolled back if needed

  2. Security:
    - Requires admin privileges
    - Maintains existing RLS policies
*/

-- Delete all leads
DELETE FROM leads;

-- Reset the sequence if any exists
ALTER SEQUENCE IF EXISTS leads_id_seq RESTART;