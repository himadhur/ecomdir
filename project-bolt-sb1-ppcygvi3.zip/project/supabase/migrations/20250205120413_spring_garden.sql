/*
  # Update leads table with additional CSV columns

  1. Changes
    Add new columns to leads table:
    - annual_sales_bucket (text): Categorizes annual sales ranges
    - product_price_bucket (text): Categorizes product price ranges
    - avg_sellers (numeric): Average number of sellers
    - top_seller_name (text): Name of the top seller
    - top_seller_country (text): Country code of the top seller
    - reviews (integer): Number of reviews
    - rating (numeric): Average rating
    - total_products (integer): Total number of products
    - storefront (boolean): Whether the seller has a storefront
    - annual_sales (numeric): Annual sales amount

  2. Security
    - Maintain existing RLS policies
*/

-- Add new columns to the leads table
ALTER TABLE leads 
ADD COLUMN IF NOT EXISTS annual_sales_bucket text,
ADD COLUMN IF NOT EXISTS product_price_bucket text,
ADD COLUMN IF NOT EXISTS avg_sellers numeric,
ADD COLUMN IF NOT EXISTS top_seller_name text,
ADD COLUMN IF NOT EXISTS top_seller_country text,
ADD COLUMN IF NOT EXISTS reviews integer,
ADD COLUMN IF NOT EXISTS rating numeric,
ADD COLUMN IF NOT EXISTS total_products integer,
ADD COLUMN IF NOT EXISTS storefront boolean,
ADD COLUMN IF NOT EXISTS annual_sales numeric;