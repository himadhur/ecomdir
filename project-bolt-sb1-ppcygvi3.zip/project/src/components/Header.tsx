import { Store, Search, Download, CreditCard, LogOut, Settings as SettingsIcon, Upload } from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export function Header() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  // Check if user has access to add leads
  const canAddLeads = user?.email === 'tarrkash@gmail.com';

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Store className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">Ecom Directory</span>
            </Link>
          </div>

          {user && (
            <div className="flex items-center space-x-4">
              <Link
                to="/search"
                className={`text-gray-600 hover:text-gray-900 flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive('/search') ? 'bg-gray-100' : ''
                }`}
              >
                <Search size={20} />
                <span>Search</span>
              </Link>
              
              <Link
                to="/downloads"
                className={`text-gray-600 hover:text-gray-900 flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive('/downloads') ? 'bg-gray-100' : ''
                }`}
              >
                <Download size={20} />
                <span>Downloads</span>
              </Link>
              
              <Link
                to="/credits"
                className={`text-gray-600 hover:text-gray-900 flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive('/credits') ? 'bg-gray-100' : ''
                }`}
              >
                <CreditCard size={20} />
                <span>Buy Credits</span>
              </Link>

              {canAddLeads && (
                <Link
                  to="/add-lead"
                  className={`text-gray-600 hover:text-gray-900 flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                    isActive('/add-lead') ? 'bg-gray-100' : ''
                  }`}
                >
                  <Upload size={20} />
                  <span>Add Lead</span>
                </Link>
              )}

              <Link
                to="/settings"
                className={`text-gray-600 hover:text-gray-900 flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive('/settings') ? 'bg-gray-100' : ''
                }`}
              >
                <SettingsIcon size={20} />
                <span>Settings</span>
              </Link>

              <button
                onClick={handleSignOut}
                className="text-gray-600 hover:text-gray-900 flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium"
              >
                <LogOut size={20} />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}