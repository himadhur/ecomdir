import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Store, Search, Download, CreditCard, Upload, Settings as SettingsIcon } from 'lucide-react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Header } from './components/Header';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Search as SearchPage } from './pages/Search';
import { Downloads } from './pages/Downloads';
import { Credits } from './pages/Credits';
import { AddLead } from './pages/AddLead';
import { Settings } from './pages/Settings';

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center">
      <Store className="h-12 w-12 text-blue-600 animate-bounce" />
      <h2 className="mt-4 text-xl font-semibold text-gray-900">Loading...</h2>
    </div>
  );
}

function ErrorScreen({ error }: { error: string }) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center">
      <div className="text-red-600 mb-4">
        <Store className="h-12 w-12" />
      </div>
      <h2 className="text-xl font-semibold text-gray-900 mb-2">Something went wrong</h2>
      <p className="text-gray-600">{error}</p>
    </div>
  );
}

function MenuCard({ 
  title, 
  description, 
  icon: Icon, 
  to, 
  gradient = "from-blue-600 to-blue-800"
}: { 
  title: string;
  description: string;
  icon: React.ElementType;
  to: string;
  gradient?: string;
}) {
  return (
    <Link 
      to={to}
      className="block group relative overflow-hidden rounded-lg shadow-lg transition-transform hover:-translate-y-1"
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-90 transition-opacity group-hover:opacity-100`}></div>
      <div className="relative p-6">
        <div className="flex items-center justify-between">
          <Icon className="h-8 w-8 text-white" />
          <div className="h-8 w-8 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
            <Icon className="h-4 w-4 text-white" />
          </div>
        </div>
        <h3 className="mt-4 text-xl font-semibold text-white">{title}</h3>
        <p className="mt-2 text-white text-opacity-90">{description}</p>
        <div className="mt-4 flex items-center text-white text-opacity-90 text-sm font-medium">
          Learn more
          <svg className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </Link>
  );
}

function Dashboard() {
  const { user } = useAuth();
  const isAdmin = user?.email === 'tarrkash@gmail.com';

  return (
    <div className="min-h-screen bg-gray-100">
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Welcome to Ecom Directory</h1>
              <p className="mt-2 text-gray-600">
                Find and analyze Amazon sellers with our comprehensive database of leads.
              </p>
            </div>
            <div className="hidden sm:block">
              <Store className="h-12 w-12 text-blue-600" />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <MenuCard
              title="Search Leads"
              description="Search our database of verified Amazon sellers with advanced filters and analytics."
              icon={Search}
              to="/search"
              gradient="from-blue-600 to-blue-800"
            />
            
            <MenuCard
              title="Downloads"
              description="Access and manage your downloaded lead lists and export history."
              icon={Download}
              to="/downloads"
              gradient="from-purple-600 to-purple-800"
            />
            
            <MenuCard
              title="Buy Credits"
              description="Purchase credits to download lead information and access premium features."
              icon={CreditCard}
              to="/credits"
              gradient="from-green-600 to-green-800"
            />

            {isAdmin && (
              <MenuCard
                title="Add Leads"
                description="Upload and manage new leads in the database."
                icon={Upload}
                to="/add-lead"
                gradient="from-orange-600 to-orange-800"
              />
            )}
            
            <MenuCard
              title="Settings"
              description="Manage your account preferences and profile information."
              icon={SettingsIcon}
              to="/settings"
              gradient="from-gray-600 to-gray-800"
            />
          </div>
        </div>
      </main>
    </div>
  );
}

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      {children}
    </div>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Dashboard />
                </AppLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Dashboard />
                </AppLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/search"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <SearchPage />
                </AppLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/downloads"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Downloads />
                </AppLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/credits"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Credits />
                </AppLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/add-lead"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <AddLead />
                </AppLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Settings />
                </AppLayout>
              </ProtectedRoute>
            }
          />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;