import { useState, useEffect } from 'react';
import { Search as SearchIcon, Download, ChevronLeft, ChevronRight, AlertCircle, RefreshCw } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { Lead, SearchFilters, Category, SubCategory, Location } from '../types/database';

interface DownloadModalProps {
  selectedCount: number;
  credits: number;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
}

function DownloadModal({ selectedCount, credits, onConfirm, onCancel, loading }: DownloadModalProps) {
  const hasEnoughCredits = credits >= selectedCount;

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Confirm Download</h3>
        
        <div className="space-y-4">
          <p className="text-sm text-gray-500">
            You are about to download {selectedCount} leads.
            This will cost {selectedCount} credits.
          </p>

          <div className="bg-gray-50 p-4 rounded-md">
            <div className="flex justify-between text-sm">
              <span className="font-medium text-gray-700">Your Credits:</span>
              <span className="text-gray-900">{credits}</span>
            </div>
            <div className="flex justify-between text-sm mt-2">
              <span className="font-medium text-gray-700">Cost:</span>
              <span className="text-gray-900">-{selectedCount}</span>
            </div>
            <div className="border-t border-gray-200 mt-2 pt-2">
              <div className="flex justify-between text-sm font-medium">
                <span className="text-gray-700">Remaining:</span>
                <span className={credits - selectedCount < 0 ? 'text-red-600' : 'text-gray-900'}>
                  {credits - selectedCount}
                </span>
              </div>
            </div>
          </div>

          {!hasEnoughCredits && (
            <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded relative flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              <span>You don't have enough credits. Please purchase more credits to continue.</span>
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-end space-x-3">
          <button
            onClick={onCancel}
            disabled={loading}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={!hasEnoughCredits || loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Processing...</span>
              </>
            ) : (
              <>
                <Download className="h-4 w-4" />
                <span>Confirm Download</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

const ITEMS_PER_PAGE = 25;
const MAX_SELECTABLE_LEADS = 25;

export function Search() {
  const { user, credits } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<SearchFilters>({});
  const [categories, setCategories] = useState<string[]>([]);
  const [subCategories, setSubCategories] = useState<string[]>([]);
  const [locations, setLocations] = useState<string[]>([]);
  const [selectedLeads, setSelectedLeads] = useState<Set<string>>(new Set());
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        setLoading(true);
        setError(null);

        const [categoriesResult, subCategoriesResult, locationsResult, leadsResult] = await Promise.all([
          supabase.rpc('get_distinct_categories'),
          supabase.rpc('get_distinct_sub_categories'),
          supabase.rpc('get_distinct_locations'),
          supabase
            .from('leads')
            .select('*', { count: 'exact' })
            .range((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE - 1)
            .order('brand_name', { ascending: true })
        ]);

        if (categoriesResult.error) throw new Error('Failed to load categories');
        if (subCategoriesResult.error) throw new Error('Failed to load sub-categories');
        if (locationsResult.error) throw new Error('Failed to load locations');
        if (leadsResult.error) throw new Error('Failed to load leads');

        const categoryData = categoriesResult.data as Category[];
        const subCategoryData = subCategoriesResult.data as SubCategory[];
        const locationData = locationsResult.data as Location[];

        setCategories(categoryData.map(c => c.category).filter(Boolean));
        setSubCategories(subCategoryData.map(sc => sc.sub_category).filter(Boolean));
        setLocations(locationData.map(l => l.location).filter(Boolean));
        setLeads(leadsResult.data || []);
        setTotalCount(leadsResult.count || 0);
      } catch (err) {
        console.error('Error loading initial data:', err);
        setError('Failed to load data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, [currentPage]);

  const handleSearch = async () => {
    try {
      setLoading(true);
      setError(null);
      setSelectedLeads(new Set()); // Clear selections on new search

      let query = supabase
        .from('leads')
        .select('*', { count: 'exact' });

      // Apply filters
      if (filters.product_category) {
        query = query.eq('product_category', filters.product_category);
      }
      if (filters.sub_category) {
        query = query.eq('sub_category', filters.sub_category);
      }
      if (filters.location) {
        query = query.eq('location', filters.location);
      }
      if (filters.min_price) {
        query = query.gte('avg_price', parseFloat(filters.min_price));
      }
      if (filters.max_price) {
        query = query.lte('avg_price', parseFloat(filters.max_price));
      }
      if (filters.min_annual_sales) {
        query = query.gte('annual_sales', parseFloat(filters.min_annual_sales));
      }
      if (filters.max_annual_sales) {
        query = query.lte('annual_sales', parseFloat(filters.max_annual_sales));
      }
      if (filters.min_reviews) {
        query = query.gte('reviews', parseInt(filters.min_reviews));
      }
      if (filters.max_reviews) {
        query = query.lte('reviews', parseInt(filters.max_reviews));
      }
      if (filters.storefront) {
        query = query.eq('storefront', filters.storefront === 'true');
      }

      // Apply pagination
      query = query
        .range((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE - 1)
        .order('brand_name', { ascending: true });

      const { data, error, count } = await query;

      if (error) throw error;

      setLeads(data || []);
      setTotalCount(count || 0);
      setCurrentPage(1); // Reset to first page on new search
    } catch (err) {
      console.error('Search error:', err);
      setError('Failed to perform search. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key: keyof SearchFilters, value: string) => {
    setFilters(prev => ({
      ...prev,
      [key]: value === '' ? undefined : value
    }));
  };

  const handleSelectAll = () => {
    if (selectedLeads.size === leads.length) {
      setSelectedLeads(new Set());
    } else {
      if (leads.length > MAX_SELECTABLE_LEADS) {
        setError(`You can only select up to ${MAX_SELECTABLE_LEADS} leads at once`);
        return;
      }
      setSelectedLeads(new Set(leads.map(lead => lead.id)));
    }
  };

  const handleSelectLead = (leadId: string) => {
    const newSelected = new Set(selectedLeads);
    if (newSelected.has(leadId)) {
      newSelected.delete(leadId);
      setError(null);
    } else {
      if (newSelected.size >= MAX_SELECTABLE_LEADS) {
        setError(`You can only select up to ${MAX_SELECTABLE_LEADS} leads at once`);
        return;
      }
      newSelected.add(leadId);
    }
    setSelectedLeads(newSelected);
  };

  const handleDownload = async () => {
    if (selectedLeads.size === 0) return;

    try {
      setDownloading(true);
      setError(null);

      // Fetch all selected leads data
      const { data: selectedLeadsData, error: fetchError } = await supabase
        .from('leads')
        .select('*')
        .in('id', Array.from(selectedLeads));

      if (fetchError) throw fetchError;

      // Create the download
      const { error: downloadError } = await supabase
        .from('downloads')
        .insert({
          user_id: user?.id,
          file_name: `leads_${new Date().toISOString().split('T')[0]}.csv`,
          lead_count: selectedLeads.size,
          total_size: JSON.stringify(selectedLeadsData).length,
          leads: selectedLeadsData,
          status: 'completed',
          download_count: 0
        });

      if (downloadError) throw downloadError;

      // Deduct credits
      const { error: creditError } = await supabase
        .from('profiles')
        .update({ credits: credits - selectedLeads.size })
        .eq('id', user?.id);

      if (creditError) throw creditError;

      // Record the transaction
      const { error: transactionError } = await supabase
        .from('credit_transactions')
        .insert({
          user_id: user?.id,
          amount: -selectedLeads.size,
          type: 'usage',
          description: `Downloaded ${selectedLeads.size} leads`,
        });

      if (transactionError) throw transactionError;

      setShowDownloadModal(false);
      setSelectedLeads(new Set());
      
      // Convert to CSV and trigger download
      const headers = [
        'Brand Name',
        'Product Category',
        'Sub Category',
        'Location',
        'Annual Sales',
        'Monthly Sales',
        'Avg Price',
        'Reviews',
        'Rating',
        'Storefront',
        'Website',
        'Email',
        'Phone'
      ];

      const csvRows = [
        headers.join(','),
        ...selectedLeadsData.map((lead: Lead) => [
          `"${lead.brand_name}"`,
          `"${lead.product_category}"`,
          `"${lead.sub_category || ''}"`,
          `"${lead.location || ''}"`,
          lead.annual_sales || '',
          lead.monthly_sales || '',
          lead.avg_price || '',
          lead.reviews || '',
          lead.rating || '',
          lead.storefront ? 'Yes' : 'No',
          `"${lead.website || ''}"`,
          `"${lead.email || ''}"`,
          `"${lead.phone || ''}"`,
        ].join(','))
      ];

      const csvContent = csvRows.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `leads_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

    } catch (err) {
      console.error('Download error:', err);
      setError('Failed to process download. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Search Leads</h1>
              <p className="mt-1 text-sm text-gray-600">
                Search and filter Amazon seller leads
              </p>
            </div>
            {selectedLeads.size > 0 && (
              <div className="mt-4 md:mt-0">
                <button
                  onClick={() => setShowDownloadModal(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Selected ({selectedLeads.size})
                </button>
              </div>
            )}
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded relative flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              <span>{error}</span>
            </div>
          )}

          <div className="bg-white shadow-sm rounded-lg">
            {/* Filters */}
            <div className="p-6 border-b border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Product Category
                  </label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value={filters.product_category || ''}
                    onChange={(e) => handleFilterChange('product_category', e.target.value)}
                  >
                    <option value="">All Categories</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Sub Category
                  </label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value={filters.sub_category || ''}
                    onChange={(e) => handleFilterChange('sub_category', e.target.value)}
                  >
                    <option value="">All Sub Categories</option>
                    {subCategories.map((subCategory) => (
                      <option key={subCategory} value={subCategory}>
                        {subCategory}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Location
                  </label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value={filters.location || ''}
                    onChange={(e) => handleFilterChange('location', e.target.value)}
                  >
                    <option value="">All Locations</option>
                    {locations.map((location) => (
                      <option key={location} value={location}>
                        {location}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Price Range
                  </label>
                  <div className="mt-1 flex space-x-2">
                    <input
                      type="number"
                      placeholder="Min"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      value={filters.min_price || ''}
                      onChange={(e) => handleFilterChange('min_price', e.target.value)}
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      value={filters.max_price || ''}
                      onChange={(e) => handleFilterChange('max_price', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Annual Sales Range
                  </label>
                  <div className="mt-1 flex space-x-2">
                    <input
                      type="number"
                      placeholder="Min"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      value={filters.min_annual_sales || ''}
                      onChange={(e) => handleFilterChange('min_annual_sales', e.target.value)}
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      value={filters.max_annual_sales || ''}
                      onChange={(e) => handleFilterChange('max_annual_sales', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Reviews Range
                  </label>
                  <div className="mt-1 flex space-x-2">
                    <input
                      type="number"
                      placeholder="Min"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      value={filters.min_reviews || ''}
                      onChange={(e) => handleFilterChange('min_reviews', e.target.value)}
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      value={filters.max_reviews || ''}
                      onChange={(e) => handleFilterChange('max_reviews', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Has Storefront
                  </label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    value={filters.storefront || ''}
                    onChange={(e) => handleFilterChange('storefront', e.target.value)}
                  >
                    <option value="">All</option>
                    <option value="true">Yes</option>
                    <option value="false">No</option>
                  </select>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSearch}
                  disabled={loading}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="animate-spin h-4 w-4 mr-2" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <SearchIcon className="h-4 w-4 mr-2" />
                      Search
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Results */}
            {loading ? (
              <div className="p-12 text-center">
                <RefreshCw className="animate-spin h-8 w-8 text-blue-600 mx-auto" />
                <p className="mt-4 text-gray-600">Loading results...</p>
              </div>
            ) : leads.length === 0 ? (
              <div className="p-12 text-center">
                <SearchIcon className="h-8 w-8 text-gray-400 mx-auto" />
                <p className="mt-4 text-gray-600">No leads found. Try adjusting your filters.</p>
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                              checked={selectedLeads.size === leads.length && leads.length > 0}
                              onChange={handleSelectAll}
                            />
                          </div>
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Brand Name
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Category
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Location
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Annual Sales
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Avg Price
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Reviews
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Rating
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Storefront
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {leads.map((lead) => (
                        <tr key={lead.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                              checked={selectedLeads.has(lead.id)}
                              onChange={() => handleSelectLead(lead.id)}
                            />
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {lead.brand_name}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{lead.product_category}</div>
                            {lead.sub_category && (
                              <div className="text-sm text-gray-500">{lead.sub_category}</div>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{lead.location || '—'}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              ${lead.annual_sales?.toLocaleString() || '—'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              ${lead.avg_price?.toLocaleString() || '—'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {lead.reviews?.toLocaleString() || '—'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {lead.rating || '—'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              lead.storefront
                                ? 'bg-green-100 text-green-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {lead.storefront ? 'Yes' : 'No'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                  <div className="flex-1 flex justify-between sm:hidden">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
                    >
                      Previous
                    </button>
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
                    >
                      Next
                    </button>
                  </div>
                  <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm text-gray-700">
                        Showing{' '}
                        <span className="font-medium">
                          {Math.min((currentPage - 1) * ITEMS_PER_PAGE + 1, totalCount)}
                        </span>{' '}
                        to{' '}
                        <span className="font-medium">
                          {Math.min(currentPage * ITEMS_PER_PAGE, totalCount)}
                        </span>{' '}
                        of{' '}
                        <span className="font-medium">{totalCount}</span>{' '}
                        results
                      </p>
                    </div>
                    <div>
                      <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                        <button
                          onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                          disabled={currentPage === 1}
                          className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                        >
                          <span className="sr-only">Previous</span>
                          <ChevronLeft className="h-5 w-5" />
                        </button>
                        {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                          let pageNumber;
                          if (totalPages <= 5) {
                            pageNumber = i + 1;
                          } else if (currentPage <= 3) {
                            pageNumber = i + 1;
                          } else if (currentPage >= totalPages - 2) {
                            pageNumber = totalPages - 4 + i;
                          } else {
                            pageNumber = currentPage - 2 + i;
                          }

                          return (
                            <button
                              key={pageNumber}
                              onClick={() => setCurrentPage(pageNumber)}
                              className={currentPage === pageNumber
                                ? "relative inline-flex items-center px-4 py-2 border text-sm font-medium z-10 bg-blue-50 border-blue-500 text-blue-600"
                                : "relative inline-flex items-center px-4 py-2 border text-sm font-medium bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                              }
                            >
                              {pageNumber}
                            </button>
                          );
                        })}
                        <button
                          onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                          disabled={currentPage === totalPages}
                          className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                        >
                          <span className="sr-only">Next</span>
                          <ChevronRight className="h-5 w-5" />
                        </button>
                      </nav>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {showDownloadModal && (
        <DownloadModal
          selectedCount={selectedLeads.size}
          credits={credits}
          onConfirm={handleDownload}
          onCancel={() => setShowDownloadModal(false)}
          loading={downloading}
        />
      )}
    </div>
  );
}