import { useState, useEffect } from 'react';
import { Download, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Download {
  id: string;
  created_at: string;
  file_name: string;
  lead_count: number;
  total_size: number;
  status: 'pending' | 'completed' | 'failed';
  download_count: number;
}

export function Downloads() {
  const { user } = useAuth();
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDownloads();
  }, [user?.id]);

  const fetchDownloads = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('downloads')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDownloads(data || []);
    } catch (error) {
      console.error('Error fetching downloads:', error);
      setError('Failed to load downloads. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (download: Download) => {
    try {
      // Get the leads data from the download record
      const { data: downloadData, error: downloadError } = await supabase
        .from('downloads')
        .select('leads')
        .eq('id', download.id)
        .single();

      if (downloadError) throw downloadError;

      // Convert leads to CSV
      const leads = downloadData.leads;
      const headers = [
        'Brand Name',
        'Product Category',
        'Sub Category',
        'Annual Sales',
        'Monthly Sales',
        'Avg Price',
        'Annual Sales Bucket',
        'Product Price Bucket',
        'Avg Sellers',
        'Top Seller Name',
        'Top Seller Country',
        'Reviews',
        'Rating',
        'Total Products',
        'Storefront',
        'Location'
      ];

      const csvRows = [
        headers.join(','),
        ...leads.map((lead: any) => [
          `"${lead.brand_name}"`,
          `"${lead.product_category}"`,
          `"${lead.sub_category || ''}"`,
          lead.annual_sales || '',
          lead.monthly_sales || '',
          lead.avg_price || '',
          `"${lead.annual_sales_bucket || ''}"`,
          `"${lead.product_price_bucket || ''}"`,
          lead.avg_sellers || '',
          `"${lead.top_seller_name || ''}"`,
          `"${lead.top_seller_country || ''}"`,
          lead.reviews || '',
          lead.rating || '',
          lead.total_products || '',
          lead.storefront ? 'Yes' : 'No',
          `"${lead.location || ''}"`
        ].join(','))
      ];

      // Create and download CSV file
      const csvContent = csvRows.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = download.file_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Update download count
      await supabase
        .from('downloads')
        .update({ download_count: download.download_count + 1 })
        .eq('id', download.id);

      // Refresh downloads list
      fetchDownloads();
    } catch (error) {
      console.error('Error downloading file:', error);
      setError('Failed to download file. Please try again.');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatFileSize = (bytes: number) => {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <h1 className="text-2xl font-semibold text-gray-900">Downloads History</h1>
          <p className="mt-2 text-gray-600">View and access your previously downloaded lead lists.</p>

          {error && (
            <div className="mt-4 bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded relative flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              <span>{error}</span>
            </div>
          )}

          <div className="mt-8">
            {loading ? (
              <div className="bg-white shadow-sm rounded-lg p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-center mt-4 text-gray-600">Loading downloads...</p>
              </div>
            ) : downloads.length === 0 ? (
              <div className="bg-white shadow-sm rounded-lg p-8 text-center">
                <Download className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No downloads yet</h3>
                <p className="text-gray-600">
                  Your downloaded lead lists will appear here. Start by searching and downloading leads from the search page.
                </p>
              </div>
            ) : (
              <div className="bg-white shadow-sm rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        File Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Leads
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Size
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Downloads
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {downloads.map((download) => (
                      <tr key={download.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatDate(download.created_at)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {download.file_name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {download.lead_count.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatFileSize(download.total_size)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {download.download_count}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            download.status === 'completed'
                              ? 'bg-green-100 text-green-800'
                              : download.status === 'failed'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {download.status.charAt(0).toUpperCase() + download.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <button
                            onClick={() => handleDownload(download)}
                            disabled={download.status !== 'completed'}
                            className="text-blue-600 hover:text-blue-900 font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <Download className="h-4 w-4 mr-1" />
                            Download Again
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}