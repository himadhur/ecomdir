import { useState } from 'react';
import { Upload, AlertCircle, CheckCircle2, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Lead } from '../types/database';

export function AddLead() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [failedLeads, setFailedLeads] = useState<any[]>([]);
  const [uploadStats, setUploadStats] = useState<{
    total: number;
    success: number;
    failed: number;
    currentBatch: number;
    totalBatches: number;
  } | null>(null);

  const processCSV = (text: string): Partial<Lead>[] => {
    const lines = text.split('\n');
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    
    return lines.slice(1)
      .filter(line => line.trim())
      .map(line => {
        const values = line.split(',').map(v => v.trim());
        const lead: Record<string, any> = {};
        
        headers.forEach((header, index) => {
          const value = values[index];
          if (value) {
            switch (header) {
              case 'monthly_sales':
              case 'annual_sales':
              case 'avg_price':
              case 'avg_sales':
                lead[header] = parseFloat(value.replace(/[^0-9.-]+/g, '')) || 0;
                break;
              case 'reviews':
                lead[header] = parseInt(value.replace(/[^0-9-]+/g, '')) || 0;
                break;
              case 'rating':
                lead[header] = parseFloat(value) || null;
                break;
              case 'storefront':
                lead[header] = value.toLowerCase() === 'true' || value.toLowerCase() === 'yes';
                break;
              default:
                lead[header] = value;
            }
          }
        });
        
        return lead;
      });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);
    setSuccess(false);
    setUploadStats(null);
    setFailedLeads([]);

    try {
      const text = await file.text();
      const leads = processCSV(text);
      
      if (leads.length === 0) {
        throw new Error('No valid leads found in the CSV file');
      }

      let successCount = 0;
      let failedCount = 0;
      const failedLeadsArray: any[] = [];
      const BATCH_SIZE = 25;
      const totalBatches = Math.ceil(leads.length / BATCH_SIZE);

      for (let i = 0; i < leads.length; i += BATCH_SIZE) {
        const currentBatch = Math.floor(i / BATCH_SIZE) + 1;
        const batch = leads.slice(i, i + BATCH_SIZE);
        
        setUploadStats({
          total: leads.length,
          success: successCount,
          failed: failedCount,
          currentBatch,
          totalBatches
        });

        try {
          const { error: insertError } = await supabase
            .from('leads')
            .insert(batch);

          if (insertError) {
            console.error('Error inserting batch:', insertError);
            failedCount += batch.length;
            failedLeadsArray.push(...batch.map(lead => ({
              ...lead,
              error: insertError.message
            })));
          } else {
            successCount += batch.length;
          }
        } catch (batchError) {
          console.error('Batch insert error:', batchError);
          failedCount += batch.length;
          failedLeadsArray.push(...batch.map(lead => ({
            ...lead,
            error: batchError instanceof Error ? batchError.message : 'Unknown error'
          })));
        }

        await new Promise(resolve => setTimeout(resolve, 100));
      }

      setUploadStats({
        total: leads.length,
        success: successCount,
        failed: failedCount,
        currentBatch: totalBatches,
        totalBatches
      });

      if (successCount > 0) {
        setSuccess(true);
      }
      if (failedCount > 0) {
        setError(`Failed to upload ${failedCount} leads`);
        setFailedLeads(failedLeadsArray);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred while processing the file');
    } finally {
      setLoading(false);
      e.target.value = '';
    }
  };

  const downloadFailedLeads = () => {
    if (failedLeads.length === 0) return;

    const headers = [
      'Brand Name',
      'Monthly Sales',
      'Product Category',
      'Sub Category',
      'Location',
      'Avg Price',
      'Avg Sales',
      'Annual Sales',
      'Annual Sales Bucket',
      'Product Price Bucket',
      'Rating',
      'Reviews',
      'Storefront',
      'Website',
      'Email',
      'Phone',
      'Error'
    ];

    const csvRows = [
      headers.join(','),
      ...failedLeads.map(lead => [
        `"${lead.brand_name || ''}"`,
        lead.monthly_sales || '',
        `"${lead.product_category || ''}"`,
        `"${lead.sub_category || ''}"`,
        `"${lead.location || ''}"`,
        lead.avg_price || '',
        lead.avg_sales || '',
        lead.annual_sales || '',
        `"${lead.annual_sales_bucket || ''}"`,
        `"${lead.product_price_bucket || ''}"`,
        lead.rating || '',
        lead.reviews || '',
        lead.storefront ? 'true' : 'false',
        `"${lead.website || ''}"`,
        `"${lead.email || ''}"`,
        `"${lead.phone || ''}"`,
        `"${lead.error || ''}"`,
      ].join(','))
    ];

    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `failed_leads_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadTemplate = () => {
    const headers = [
      'brand_name',
      'monthly_sales',
      'product_category',
      'sub_category',
      'location',
      'avg_price',
      'avg_sales',
      'annual_sales',
      'annual_sales_bucket',
      'product_price_bucket',
      'rating',
      'reviews',
      'storefront',
      'website',
      'email',
      'phone'
    ];

    const exampleData = [
      'TechPro,50000,Electronics,Accessories,US,129.99,75000,600000,500K_to_1M,100_to_500,4.7,1250,true,https://example.com,contact@techpro.com,+1234567890',
      'HomeGoods,35000,Home & Kitchen,Appliances,CA,45.99,32000,420000,250K_to_500K,25_to_100,4.5,890,false,,,',
      'FitLife,43000,Sports & Outdoors,Fitness Equipment,UK,89.99,40000,516000,500K_to_1M,50_to_100,4.8,2100,true,,,'
    ];

    const csvContent = [headers.join(','), ...exampleData].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'leads_import_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="bg-white shadow-sm rounded-lg p-6">
          <div className="md:flex md:items-center md:justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Upload Leads</h2>
              <p className="mt-1 text-sm text-gray-500">
                Upload your leads using a CSV file
              </p>
            </div>
            <div className="mt-4 md:mt-0 space-x-4">
              <button
                onClick={downloadTemplate}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Template
              </button>
              {failedLeads.length > 0 && (
                <button
                  onClick={downloadFailedLeads}
                  className="inline-flex items-center px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Failed Leads
                </button>
              )}
            </div>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded relative flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              <span className="block sm:inline">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-6 bg-green-50 border border-green-400 text-green-700 px-4 py-3 rounded relative flex items-center">
              <CheckCircle2 className="h-5 w-5 mr-2" />
              <span className="block sm:inline">Leads uploaded successfully!</span>
            </div>
          )}

          <div className="space-y-6">
            {/* CSV Upload Section */}
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
              <div className="text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="mt-4">
                  <label
                    htmlFor="file-upload"
                    className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                  >
                    <span>Upload a CSV file</span>
                    <input
                      id="file-upload"
                      name="file-upload"
                      type="file"
                      accept=".csv"
                      className="sr-only"
                      onChange={handleFileUpload}
                      disabled={loading}
                    />
                  </label>
                </div>
                <p className="mt-2 text-sm text-gray-500">
                  {loading ? 'Uploading...' : 'CSV file up to 10MB'}
                </p>
              </div>

              {uploadStats && (
                <div className="mt-6 border-t border-gray-200 pt-6">
                  <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-3">
                    <div className="sm:col-span-1">
                      <dt className="text-sm font-medium text-gray-500">Total Leads</dt>
                      <dd className="mt-1 text-sm text-gray-900">{uploadStats.total}</dd>
                    </div>
                    <div className="sm:col-span-1">
                      <dt className="text-sm font-medium text-gray-500">Successfully Uploaded</dt>
                      <dd className="mt-1 text-sm text-green-600">{uploadStats.success}</dd>
                    </div>
                    <div className="sm:col-span-1">
                      <dt className="text-sm font-medium text-gray-500">Failed</dt>
                      <dd className="mt-1 text-sm text-red-600">{uploadStats.failed}</dd>
                    </div>
                    {loading && (
                      <div className="sm:col-span-3">
                        <dt className="text-sm font-medium text-gray-500">Progress</dt>
                        <dd className="mt-1">
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div 
                              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
                              style={{ width: `${(uploadStats.currentBatch / uploadStats.totalBatches) * 100}%` }}
                            ></div>
                          </div>
                          <p className="mt-2 text-sm text-gray-500">
                            Processing batch {uploadStats.currentBatch} of {uploadStats.totalBatches}
                          </p>
                        </dd>
                      </div>
                    )}
                  </dl>
                </div>
              )}
            </div>

            {/* CSV Format Guide */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">CSV Format Guide</h3>
              <p className="text-sm text-gray-600 mb-4">
                Download the template above or create a CSV file with the following columns (header names are case-insensitive):
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Required Fields:</h4>
                  <ul className="text-sm text-gray-600 list-disc list-inside space-y-1">
                    <li>brand_name (text)</li>
                    <li>monthly_sales (number)</li>
                    <li>product_category (text)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Optional Fields:</h4>
                  <ul className="text-sm text-gray-600 list-disc list-inside space-y-1">
                    <li>sub_category (text)</li>
                    <li>location (text)</li>
                    <li>avg_price (number)</li>
                    <li>avg_sales (number)</li>
                    <li>annual_sales (number)</li>
                    <li>annual_sales_bucket (text)</li>
                    <li>product_price_bucket (text)</li>
                    <li>rating (number, 0-5)</li>
                    <li>reviews (number)</li>
                    <li>storefront (true/false)</li>
                    <li>website (URL)</li>
                    <li>email (email)</li>
                    <li>phone (text)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Value Formats:</h4>
                  <ul className="text-sm text-gray-600 list-disc list-inside space-y-1">
                    <li>Numbers: No currency symbols</li>
                    <li>Text: Wrap in quotes if contains commas</li>
                    <li>Boolean: true/false or yes/no</li>
                    <li>Dates: YYYY-MM-DD format</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}