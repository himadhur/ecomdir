import { useState, useEffect } from 'react';
import { CreditCard, Package, ArrowDown, ArrowUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface CreditPackage {
  id: number;
  name: string;
  credits: number;
  price: number;
  description: string;
  popular?: boolean;
}

interface Transaction {
  id: string;
  amount: number;
  type: 'purchase' | 'usage';
  description: string;
  created_at: string;
  payment_status?: string;
}

const creditPackages: CreditPackage[] = [
  {
    id: 1,
    name: 'Starter',
    credits: 100,
    price: 49,
    description: 'Perfect for small businesses just getting started'
  },
  {
    id: 2,
    name: 'Professional',
    credits: 500,
    price: 199,
    description: 'Most popular choice for growing businesses',
    popular: true
  },
  {
    id: 3,
    name: 'Enterprise',
    credits: 2000,
    price: 699,
    description: 'Best value for large-scale operations'
  }
];

export function Credits() {
  const { user, credits, refreshCredits } = useAuth();
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  const [loading, setLoading] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [transactionsLoading, setTransactionsLoading] = useState(true);

  useEffect(() => {
    refreshCredits();
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      const { data, error } = await supabase
        .from('credit_transactions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setTransactionsLoading(false);
    }
  };

  const handlePurchase = async (pkg: CreditPackage) => {
    setSelectedPackage(pkg);
    setLoading(true);

    try {
      // Here you would integrate with your payment processor
      // For now, we'll simulate a successful purchase
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('credits')
        .eq('id', user?.id)
        .single();

      if (profileError) throw profileError;

      const newCredits = (profile?.credits || 0) + pkg.credits;

      const { error: updateError } = await supabase
        .from('profiles')
        .update({ credits: newCredits })
        .eq('id', user?.id);

      if (updateError) throw updateError;

      // Record the transaction
      const { error: transactionError } = await supabase
        .from('credit_transactions')
        .insert({
          user_id: user?.id,
          amount: pkg.credits,
          type: 'purchase',
          description: `Purchased ${pkg.credits} credits (${pkg.name} Package)`,
          payment_status: 'completed'
        });

      if (transactionError) throw transactionError;

      await refreshCredits();
      await fetchTransactions();
      alert('Purchase successful! Credits have been added to your account.');
    } catch (error) {
      console.error('Error processing purchase:', error);
      alert('Failed to process purchase. Please try again.');
    } finally {
      setLoading(false);
      setSelectedPackage(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Purchase Credits</h1>
              <p className="mt-2 text-gray-600">
                Credits are required to download lead lists. Each lead costs 1 credit.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-sm px-6 py-4">
              <div className="text-sm text-gray-600">Current Balance</div>
              <div className="text-2xl font-bold text-gray-900">{credits} Credits</div>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {creditPackages.map((pkg) => (
              <div
                key={pkg.id}
                className={`relative bg-white rounded-lg shadow-sm overflow-hidden ${
                  pkg.popular ? 'ring-2 ring-blue-500' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-0 right-0 bg-blue-500 text-white px-3 py-1 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6">
                  <div className="flex items-center">
                    <Package className="h-8 w-8 text-blue-600" />
                    <h3 className="ml-3 text-xl font-semibold text-gray-900">{pkg.name}</h3>
                  </div>
                  <div className="mt-4">
                    <p className="text-sm text-gray-500">{pkg.description}</p>
                    <p className="mt-8">
                      <span className="text-4xl font-extrabold text-gray-900">${pkg.price}</span>
                    </p>
                    <p className="mt-2 text-sm text-gray-500">
                      Includes {pkg.credits.toLocaleString()} credits
                      <br />
                      (${(pkg.price / pkg.credits).toFixed(2)} per credit)
                    </p>
                  </div>
                  <button
                    onClick={() => handlePurchase(pkg)}
                    disabled={loading && selectedPackage?.id === pkg.id}
                    className="mt-6 w-full inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                  >
                    {loading && selectedPackage?.id === pkg.id ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Processing...
                      </>
                    ) : (
                      <>
                        <CreditCard className="h-4 w-4 mr-2" />
                        Purchase Now
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Transaction History */}
          <div className="mt-12">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Transaction History</h2>
            <div className="bg-white shadow-sm rounded-lg overflow-hidden">
              {transactionsLoading ? (
                <div className="p-6 text-center">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-2 text-sm text-gray-500">Loading transactions...</p>
                </div>
              ) : transactions.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  No transactions found. Purchase credits to get started!
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Type
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Description
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {transactions.map((transaction) => (
                        <tr key={transaction.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatDate(transaction.created_at)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              {transaction.type === 'purchase' ? (
                                <ArrowUp className="h-4 w-4 text-green-500 mr-1" />
                              ) : (
                                <ArrowDown className="h-4 w-4 text-red-500 mr-1" />
                              )}
                              <span className={`text-sm ${
                                transaction.type === 'purchase' ? 'text-green-600' : 'text-red-600'
                              }`}>
                                {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {transaction.description}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {transaction.amount} credits
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {transaction.type === 'purchase' && (
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                transaction.payment_status === 'completed'
                                  ? 'bg-green-100 text-green-800'
                                  : transaction.payment_status === 'failed'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-yellow-100 text-yellow-800'
                              }`}>
                                {transaction.payment_status?.charAt(0).toUpperCase() + transaction.payment_status?.slice(1)}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          <div className="mt-12 bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900">Frequently Asked Questions</h2>
            <dl className="mt-6 space-y-6">
              <div>
                <dt className="text-sm font-medium text-gray-900">What are credits used for?</dt>
                <dd className="mt-2 text-sm text-gray-500">
                  Credits are used to download lead information. Each lead in a download list costs 1 credit.
                </dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-900">Do credits expire?</dt>
                <dd className="mt-2 text-sm text-gray-500">
                  No, your purchased credits never expire and can be used at any time.
                </dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-900">Can I get a refund?</dt>
                <dd className="mt-2 text-sm text-gray-500">
                  Credits are non-refundable once purchased. Please make sure to review your selection before purchasing.
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}