export interface Lead {
  id: string;
  brand_name: string;
  monthly_sales: number;
  annual_sales: number;
  product_category: string;
  sub_category?: string;
  location?: string;
  avg_price?: number;
  avg_sales?: number;
  website?: string;
  email?: string;
  phone?: string;
  created_at: string;
  updated_at: string;
  annual_sales_bucket?: string;
  product_price_bucket?: string;
  avg_sellers?: number;
  top_seller_name?: string;
  top_seller_country?: string;
  reviews?: number;
  rating?: number;
  total_products?: number;
  storefront?: boolean;
}

export interface SearchFilters {
  product_category?: string;
  sub_category?: string;
  location?: string;
  min_price?: string;
  max_price?: string;
  min_annual_sales?: string;
  max_annual_sales?: string;
  min_reviews?: string;
  max_reviews?: string;
  storefront?: string;
}

export interface Category {
  category: string;
}

export interface SubCategory {
  sub_category: string;
}

export interface Location {
  location: string;
}